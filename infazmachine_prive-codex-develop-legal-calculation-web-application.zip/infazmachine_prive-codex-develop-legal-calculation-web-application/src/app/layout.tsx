import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "InfazMachine",
  description: "5275 m.107-108 açıklanabilir infaz hesaplayıcı"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="tr">
      <body className="min-h-screen">{children}</body>
    </html>
  );
}
