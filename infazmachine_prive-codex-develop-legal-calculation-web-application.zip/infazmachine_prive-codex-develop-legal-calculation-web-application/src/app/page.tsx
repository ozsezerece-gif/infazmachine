import { CalculatorForm } from "@/components/CalculatorForm";

export default function HomePage() {
  return (
    <main className="mx-auto max-w-5xl space-y-6 p-8">
      <header className="space-y-2">
        <h1 className="text-3xl font-bold">InfazMachine (MVP)</h1>
        <p className="text-sm text-slate-600">5275 m.107-108 tabanlı açıklanabilir hesap. Bilgilendirme amaçlıdır.</p>
      </header>
      <section className="rounded-xl border bg-white p-6 shadow-sm">
        <CalculatorForm />
      </section>
      <section className="rounded-xl border bg-amber-50 p-4 text-sm">
        <strong>NEEDS_LEGAL_SOURCE:</strong> 5275 107-108 kaynak DOCX bu ortamda bulunamadığı için bazı suç listeleri/tavan kombinasyonları
        varsayımlı olarak işaretlenmiştir.
      </section>
    </main>
  );
}
