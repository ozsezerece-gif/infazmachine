export default function ReportPage() {
  return (
    <main className="mx-auto max-w-4xl p-8 print:p-4">
      <h1 className="mb-4 text-2xl font-bold">Hesap Raporu (Print/PDF)</h1>
      <p className="mb-2 text-sm">Bu sayfa tarayıcıdan yazdırılarak PDF olarak alınır.</p>
      <p className="text-sm text-amber-700">Not: Sunucu tarafı PDF üretimi MVP'de yok, client print destekleniyor.</p>
    </main>
  );
}
