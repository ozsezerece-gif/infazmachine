"use client";

import { useState } from "react";
import { calculateInfaz } from "@/engine/calculate";
import { CaseInput } from "@/engine/types";

const sample: CaseInput = {
  dosyaNo: "MVP-001",
  startDate: "2026-01-01",
  conversionStandard: "fixed_365_30",
  calculationPolicy: "strictest_ratio_applies",
  juvenileDayMultiplierEnabled: false,
  sentences: [
    {
      ilamNo: "2026/1",
      sucTarihi: "2024-02-10",
      cezaTuru: "sureli",
      sure: { years: 6, months: 0, days: 0 },
      tckMadde: "86/1",
      hukumluStatusu: "yetiskin",
      tekerrur: "yok",
      orgutSucluMu: false,
      m107_2_exception_auto: false,
      m108_9_special_auto: false
    }
  ]
};

export function CalculatorForm() {
  const [payload, setPayload] = useState(JSON.stringify(sample, null, 2));
  const [output, setOutput] = useState<string>("");

  return (
    <div className="space-y-4">
      <p className="text-sm text-slate-600">JSON girip hesaplamayı çalıştırın. UI şimdilik MVP hızlı giriş modunda.</p>
      <textarea
        className="h-72 w-full rounded border p-3 font-mono text-xs"
        value={payload}
        onChange={(e) => setPayload(e.target.value)}
      />
      <button
        className="rounded bg-blue-600 px-4 py-2 text-white"
        onClick={() => {
          try {
            const parsed = JSON.parse(payload) as CaseInput;
            const result = calculateInfaz(parsed);
            setOutput(JSON.stringify(result, null, 2));
          } catch (error) {
            setOutput(`Hata: ${(error as Error).message}`);
          }
        }}
      >
        Hesapla
      </button>
      <pre className="max-h-[40rem] overflow-auto rounded bg-slate-900 p-4 text-xs text-slate-100">{output}</pre>
    </div>
  );
}
