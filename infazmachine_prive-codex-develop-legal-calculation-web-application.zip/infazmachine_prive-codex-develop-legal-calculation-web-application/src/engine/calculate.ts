import { rules, RULESET_VERSION } from "./ruleset";
import { addDays, calculateMahsupDays, durationToDays, yearsToDays } from "./utils";
import { CaseInput, CalculationResult, SentenceInput, SentenceResult, Step } from "./types";

function is107_2(sentence: SentenceInput): boolean {
  return sentence.m107_2_exception_override ?? sentence.m107_2_exception_auto;
}

function is108_9(sentence: SentenceInput): boolean {
  return sentence.m108_9_special_override ?? sentence.m108_9_special_auto;
}

function calculateSentenceDays(sentence: SentenceInput, input: CaseInput): SentenceResult {
  const isChild = sentence.hukumluStatusu === "cocuk";
  const orgutApplicable = sentence.orgutSucluMu && !isChild;

  if (sentence.cezaTuru === "muebbet") {
    const years = sentence.tekerrur === "tekerrur" || sentence.tekerrur === "ikinci_tekerrur"
      ? rules.article108.tekerrur.muebbetYears
      : rules.article107.general.muebbetYears;
    return {
      ilamNo: sentence.ilamNo,
      classifiedBy: sentence.tekerrur === "yok" ? "m.107/1" : "m.108/1",
      requiredDays: yearsToDays(years),
      fixedYearsApplied: years,
      explain: `Müebbet için sabit ${years} yıl uygulandı.`
    };
  }

  if (sentence.cezaTuru === "agirlastirilmis_muebbet") {
    const years = sentence.tekerrur === "tekerrur" || sentence.tekerrur === "ikinci_tekerrur"
      ? rules.article108.tekerrur.aggravatedYears
      : rules.article107.general.aggravatedYears;
    return {
      ilamNo: sentence.ilamNo,
      classifiedBy: sentence.tekerrur === "yok" ? "m.107/1" : "m.108/1",
      requiredDays: yearsToDays(years),
      fixedYearsApplied: years,
      explain: `Ağırlaştırılmış müebbet için sabit ${years} yıl uygulandı.`
    };
  }

  const totalDays = durationToDays(sentence.sure ?? { years: 0, months: 0, days: 0 }, input.conversionStandard);

  let ratio = rules.article107.general.sureliRatio;
  let by = "m.107/1";

  if (is107_2(sentence)) {
    ratio = Math.max(ratio, rules.article107.exception107_2.sureliRatio);
    by = "m.107/2";
  }

  if (sentence.tekerrur === "tekerrur") {
    ratio = Math.max(ratio, rules.article108.tekerrur.sureliRatio);
    by = "m.108/1";
  }

  if (sentence.tekerrur === "ikinci_tekerrur") {
    ratio = Math.max(ratio, rules.article108.ikinciTekerrur.sureliRatio);
    by = "m.108/3";
  }

  if (is108_9(sentence)) {
    ratio = Math.max(ratio, rules.article108.special108_9.sureliRatio);
    by = "m.108/9";
  }

  if (orgutApplicable) {
    by = `${by} + m.107/4`;
  }

  let required = Math.ceil(totalDays * ratio);
  if (input.juvenileDayMultiplierEnabled && input.juvenileDayMultiplierAgeUnder15 && isChild) {
    required = Math.ceil(required / 2);
  }

  return {
    ilamNo: sentence.ilamNo,
    classifiedBy: by,
    requiredDays: required,
    ratioApplied: ratio,
    explain: `Süreli ceza ${totalDays} gün, oran ${ratio}, gereken ${required} gün.`
  };
}

function applyCaps(requiredDays: number, sentenceResults: SentenceResult[]): { requiredDays: number; cap?: string } {
  const hasTekerrurMultipleSureli = sentenceResults.length > 1 && sentenceResults.some((s) => (s.ratioApplied ?? 0) >= rules.article108.tekerrur.sureliRatio);
  if (hasTekerrurMultipleSureli) {
    const cap = yearsToDays(rules.article108.tekerrur.multipleSureliCapYears);
    if (requiredDays > cap) {
      return { requiredDays: cap, cap: "m.108/1(c) 32 yıl tavan" };
    }
  }
  return { requiredDays };
}

export function calculateInfaz(input: CaseInput): CalculationResult {
  const steps: Step[] = [];
  const assumptions: string[] = [];
  const needsLegalSource: string[] = [];

  steps.push({
    title: "Rule set başlatıldı",
    legalBasis: "5275 m.107-108",
    details: `Yalnızca kullanıcı tarafından verilen maddelerle hesap yapılır. Sürüm: ${RULESET_VERSION}`
  });

  if (rules.article107.exception107_2.tckListNeedsSource) {
    needsLegalSource.push("m.107/2 suç listesi tam metin doğrulaması gerekiyor.");
  }
  if (rules.article108.special108_9.listedCrimesSourceNeeded) {
    needsLegalSource.push("m.108/9 suç listesi tam metin doğrulaması gerekiyor.");
  }
  if (rules.article107.combos107_3.needsStructuredSource) {
    assumptions.push("ASSUMPTION: m.107/3 kombinasyon tavanları olay tipine göre kural motorunda kullanıcı politikası ile sadeleştirildi.");
  }
  if (rules.article107.orgut107_4.capsNeedsSource) {
    needsLegalSource.push("m.107/4 süre ve tavanlarının tam metin ayrımı gerekiyor.");
  }

  const sentenceResults = input.sentences.map((s) => calculateSentenceDays(s, input));
  sentenceResults.forEach((result) => {
    steps.push({
      title: `İlâm ${result.ilamNo} sınıflandırması`,
      legalBasis: result.classifiedBy,
      details: result.explain,
      values: {
        requiredDays: result.requiredDays,
        ratioApplied: result.ratioApplied ?? "fixed-year"
      }
    });
  });

  const totalSentenceDays = input.sentences.reduce((acc, s) => {
    if (s.cezaTuru !== "sureli") return acc;
    return acc + durationToDays(s.sure ?? { years: 0, months: 0, days: 0 }, input.conversionStandard);
  }, 0);

  let requiredByPolicy = 0;
  if (input.calculationPolicy === "per_sentence_then_sum") {
    requiredByPolicy = sentenceResults.reduce((acc, r) => acc + r.requiredDays, 0);
  } else {
    const strictest = Math.max(...sentenceResults.map((s) => s.ratioApplied ?? 0));
    requiredByPolicy = sentenceResults.reduce((acc, s) => acc + (s.ratioApplied ? 0 : s.requiredDays), 0);
    requiredByPolicy += Math.ceil(totalSentenceDays * (strictest || rules.article107.general.sureliRatio));
    assumptions.push("ASSUMPTION: Strictest ratio applies politikasında süreli ilâmlar için en yüksek oran toplam süreliye uygulandı.");
  }

  const capped = applyCaps(requiredByPolicy, sentenceResults);
  if (capped.cap) {
    steps.push({
      title: "Tavan uygulaması",
      legalBasis: capped.cap,
      details: "Hesaplanan infaz süresi yasal tavana çekildi.",
      values: { beforeCap: requiredByPolicy, afterCap: capped.requiredDays }
    });
  }

  const mahsupDays = calculateMahsupDays(input.mahsup);
  const effectiveInfazDays = Math.max(0, capped.requiredDays - mahsupDays);
  const kosulluSalivermeDate = addDays(input.startDate, effectiveInfazDays);

  steps.push({
    title: "Nihai tarih",
    legalBasis: "m.107-108 + mahsup",
    details: "Başlangıç tarihine gereken gün eklendi ve mahsup düşüldü.",
    values: { startDate: input.startDate, requiredDays: capped.requiredDays, mahsupDays, effectiveInfazDays, kosulluSalivermeDate }
  });

  return {
    rulesetVersion: RULESET_VERSION,
    generatedAt: new Date().toISOString(),
    warning: "Bu hesap bilgilendirme amaçlıdır.",
    needsLegalSource,
    assumptions,
    inputSummary: {
      startDate: input.startDate,
      sentenceCount: input.sentences.length,
      policy: input.calculationPolicy,
      conversionStandard: input.conversionStandard
    },
    totalSentenceDays,
    requiredInfazDays: capped.requiredDays,
    mahsupDays,
    effectiveInfazDays,
    kosulluSalivermeDate,
    steps,
    sentenceResults,
    topCapApplied: capped.cap,
    denetimliSerbestlik: "Not implemented (needs legal source)"
  };
}
