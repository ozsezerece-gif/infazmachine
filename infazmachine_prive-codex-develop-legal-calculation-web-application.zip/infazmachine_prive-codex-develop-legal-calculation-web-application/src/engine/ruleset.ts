export const RULESET_VERSION = "RuleSet v2026-02-14";

export const rules = {
  article107: {
    general: {
      sureliRatio: 1 / 2,
      muebbetYears: 24,
      aggravatedYears: 30
    },
    exception107_2: {
      sureliRatio: 2 / 3,
      tckListNeedsSource: true
    },
    combos107_3: {
      capsYears: [28, 32, 34, 40],
      needsStructuredSource: true
    },
    orgut107_4: {
      appliesToChildren: false,
      capsNeedsSource: true
    },
    dayForDay107_5: {
      oneDayCountsAsTwoWhenUnder15: true
    }
  },
  article108: {
    tekerrur: {
      sureliRatio: 2 / 3,
      muebbetYears: 33,
      aggravatedYears: 39,
      multipleSureliCapYears: 32
    },
    ikinciTekerrur: {
      sureliRatio: 3 / 4
    },
    special108_9: {
      sureliRatio: 3 / 4,
      listedCrimesSourceNeeded: true
    },
    addOn108_2: {
      implemented: true,
      note: "eklenecek miktar sınırı kaynak metin olmadan genel formda uygulanamaz"
    }
  }
} as const;
