export type SentenceType = "sureli" | "muebbet" | "agirlastirilmis_muebbet";
export type ConvictStatus = "yetiskin" | "cocuk";
export type Recidivism = "yok" | "tekerrur" | "ikinci_tekerrur";
export type CalculationPolicy = "strictest_ratio_applies" | "per_sentence_then_sum";
export type ConversionStandard = "fixed_365_30" | "calendar_based";

export type DurationYMD = { years: number; months: number; days: number };

export type SentenceInput = {
  ilamNo: string;
  sucTarihi: string;
  cezaTuru: SentenceType;
  sure?: DurationYMD;
  tckMadde: string;
  hukumluStatusu: ConvictStatus;
  tekerrur: Recidivism;
  orgutSucluMu: boolean;
  m107_2_exception_auto: boolean;
  m107_2_exception_override?: boolean;
  m108_9_special_auto: boolean;
  m108_9_special_override?: boolean;
  not?: string;
};

export type MahsupInput =
  | { mode: "totalDays"; totalDays: number }
  | { mode: "range"; startDate: string; endDate: string };

export type CaseInput = {
  dosyaNo: string;
  startDate: string;
  mahsup?: MahsupInput;
  conversionStandard: ConversionStandard;
  calculationPolicy: CalculationPolicy;
  juvenileDayMultiplierEnabled?: boolean;
  juvenileDayMultiplierAgeUnder15?: boolean;
  sentences: SentenceInput[];
};

export type Step = {
  title: string;
  legalBasis: string;
  details: string;
  values?: Record<string, string | number | boolean>;
  assumption?: boolean;
};

export type SentenceResult = {
  ilamNo: string;
  classifiedBy: string;
  requiredDays: number;
  ratioApplied?: number;
  fixedYearsApplied?: number;
  explain: string;
};

export type CalculationResult = {
  rulesetVersion: string;
  generatedAt: string;
  warning: string;
  needsLegalSource: string[];
  assumptions: string[];
  inputSummary: {
    startDate: string;
    sentenceCount: number;
    policy: CalculationPolicy;
    conversionStandard: ConversionStandard;
  };
  totalSentenceDays: number;
  requiredInfazDays: number;
  mahsupDays: number;
  effectiveInfazDays: number;
  kosulluSalivermeDate: string;
  steps: Step[];
  sentenceResults: SentenceResult[];
  topCapApplied?: string;
  denetimliSerbestlik: "Not implemented (needs legal source)";
};
