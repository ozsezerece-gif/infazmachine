import { ConversionStandard, DurationYMD, MahsupInput } from "./types";

export function durationToDays(duration: DurationYMD, standard: ConversionStandard): number {
  if (standard === "fixed_365_30") {
    return duration.years * 365 + duration.months * 30 + duration.days;
  }
  return duration.years * 365 + duration.months * 30 + duration.days;
}

export function yearsToDays(years: number): number {
  return years * 365;
}

export function calculateMahsupDays(mahsup?: MahsupInput): number {
  if (!mahsup) return 0;
  if (mahsup.mode === "totalDays") return Math.max(0, mahsup.totalDays);
  const start = new Date(mahsup.startDate);
  const end = new Date(mahsup.endDate);
  const diff = Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
  return Math.max(0, diff + 1);
}

export function addDays(baseDate: string, days: number): string {
  const date = new Date(baseDate);
  date.setDate(date.getDate() + days);
  return date.toISOString().slice(0, 10);
}

export function daysToYMD(days: number): { years: number; months: number; days: number } {
  const years = Math.floor(days / 365);
  const remAfterYears = days % 365;
  const months = Math.floor(remAfterYears / 30);
  const remainingDays = remAfterYears % 30;
  return { years, months, days: remainingDays };
}
