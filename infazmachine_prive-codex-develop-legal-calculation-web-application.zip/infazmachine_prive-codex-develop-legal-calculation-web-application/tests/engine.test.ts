import { describe, expect, it } from "vitest";
import { calculateInfaz } from "../src/engine/calculate";
import { readFileSync } from "node:fs";
import { join } from "node:path";

describe("infaz engine scenarios", () => {
  it("tek sureli ceza m107 genel", () => {
    const result = calculateInfaz({
      dosyaNo: "S1",
      startDate: "2026-01-01",
      conversionStandard: "fixed_365_30",
      calculationPolicy: "per_sentence_then_sum",
      sentences: [
        {
          ilamNo: "1",
          sucTarihi: "2020-01-01",
          cezaTuru: "sureli",
          sure: { years: 4, months: 0, days: 0 },
          tckMadde: "86/1",
          hukumluStatusu: "yetiskin",
          tekerrur: "yok",
          orgutSucluMu: false,
          m107_2_exception_auto: false,
          m108_9_special_auto: false
        }
      ]
    });
    expect(result.requiredInfazDays).toBe(730);
  });

  it("coklu sureli tekerrur tavan", () => {
    const result = calculateInfaz({
      dosyaNo: "S2",
      startDate: "2026-01-01",
      conversionStandard: "fixed_365_30",
      calculationPolicy: "per_sentence_then_sum",
      sentences: Array.from({ length: 3 }).map((_, i) => ({
        ilamNo: `${i + 1}`,
        sucTarihi: "2020-01-01",
        cezaTuru: "sureli" as const,
        sure: { years: 20, months: 0, days: 0 },
        tckMadde: "149/1",
        hukumluStatusu: "yetiskin" as const,
        tekerrur: "tekerrur" as const,
        orgutSucluMu: false,
        m107_2_exception_auto: false,
        m108_9_special_auto: false
      }))
    });
    expect(result.topCapApplied).toBe("m.108/1(c) 32 yıl tavan");
    expect(result.requiredInfazDays).toBe(32 * 365);
  });

  it("ikinci tekerrur 3/4", () => {
    const result = calculateInfaz({
      dosyaNo: "S3",
      startDate: "2026-01-01",
      conversionStandard: "fixed_365_30",
      calculationPolicy: "per_sentence_then_sum",
      sentences: [
        {
          ilamNo: "1",
          sucTarihi: "2020-01-01",
          cezaTuru: "sureli",
          sure: { years: 8, months: 0, days: 0 },
          tckMadde: "188",
          hukumluStatusu: "yetiskin",
          tekerrur: "ikinci_tekerrur",
          orgutSucluMu: false,
          m107_2_exception_auto: false,
          m108_9_special_auto: false
        }
      ]
    });
    expect(result.requiredInfazDays).toBe(2190);
  });
});

describe("golden fixtures", () => {
  for (let i = 1; i <= 10; i++) {
    it(`fixture ${i} matches snapshot`, () => {
      const input = JSON.parse(readFileSync(join(process.cwd(), `tests/fixtures/case-${i}.json`), "utf8"));
      const result = calculateInfaz(input);
      expect({ requiredInfazDays: result.requiredInfazDays, topCapApplied: result.topCapApplied, sentenceResults: result.sentenceResults }).toMatchSnapshot();
    });
  }
});
